# Bug Dashboard — Node.js

A local web dashboard that pulls Jira bug data from 3 filters and renders it in the browser.

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure your `.env` file
Open `.env` and fill in your details:

```env
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_EMAIL=your@email.com
JIRA_API_TOKEN=your_api_token_here

VALID_BUGS_FILTER_ID=18907
INVALID_BUGS_FILTER_ID=18909
PASSED_STORIES_FILTER_ID=18912
```

> **How to get your API token:**
> Go to https://id.atlassian.com/manage-profile/security/api-tokens → Create API token

### 3. Run the server
```bash
npm start
```

Then open your browser at:
```
http://localhost:3000
```

### 4. (Optional) Auto-reload on code changes
```bash
npm run dev
```

---

## Project Structure

```
bug-dashboard/
├── server.js          ← Express server + Jira API calls + data processing
├── public/
│   └── index.html     ← Dashboard UI (HTML + CSS + JS)
├── .env               ← Your credentials (never commit this)
├── package.json
└── README.md
```

---

## How it works

1. Browser opens `http://localhost:3000`
2. Page calls `/api/dashboard`
3. Server makes **3 parallel Jira API calls** (valid bugs, invalid bugs, passed stories)
4. Server processes and merges all data, sends JSON back
5. Browser renders the full dashboard

The **Refresh Data** button re-fetches live from Jira without reloading the page.
